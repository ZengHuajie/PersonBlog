# vue-emoji-comment

最近在写自己的个人博客时，还差最后一个评论功能，一个没有评论功能的博客是没有灵魂的，哈哈哈。

### 效果演示
![image](https://github.com/pppercyWang/vue-emoji-comment/blob/master/src/assets/img/demo_comment.gif)

使用精灵图 + 背景定位实现，大家也可以自定义这些emoji表情。看看源码，有注释。就明白怎么弄了。

这里推荐一个做精灵图的在线地址：https://sprite.ydr.me/

##### 个人博客：https://github.com/pppercyWang/twitter-blog-vue  （待完成）

### Project setup
```
yarn install

yarn serve
```